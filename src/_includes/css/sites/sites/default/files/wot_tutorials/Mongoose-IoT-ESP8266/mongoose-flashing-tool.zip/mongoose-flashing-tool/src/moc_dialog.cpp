/****************************************************************************
** Meta object code from reading C++ file 'dialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "dialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainDialog_t {
    QByteArrayData data[42];
    char stringdata0[562];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainDialog_t qt_meta_stringdata_MainDialog = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainDialog"
QT_MOC_LITERAL(1, 11, 9), // "gotPrompt"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 16), // "showPromptResult"
QT_MOC_LITERAL(4, 39, 14), // "clicked_button"
QT_MOC_LITERAL(5, 54, 12), // "flashClicked"
QT_MOC_LITERAL(6, 67, 25), // "connectDisconnectTerminal"
QT_MOC_LITERAL(7, 93, 14), // "updatePortList"
QT_MOC_LITERAL(8, 108, 18), // "selectFirmwareFile"
QT_MOC_LITERAL(9, 127, 12), // "flashingDone"
QT_MOC_LITERAL(10, 140, 3), // "msg"
QT_MOC_LITERAL(11, 144, 7), // "success"
QT_MOC_LITERAL(12, 152, 18), // "disconnectTerminal"
QT_MOC_LITERAL(13, 171, 12), // "util::Status"
QT_MOC_LITERAL(14, 184, 10), // "readSerial"
QT_MOC_LITERAL(15, 195, 11), // "writeSerial"
QT_MOC_LITERAL(16, 207, 6), // "reboot"
QT_MOC_LITERAL(17, 214, 13), // "configureWiFi"
QT_MOC_LITERAL(18, 228, 10), // "uploadFile"
QT_MOC_LITERAL(19, 239, 15), // "platformChanged"
QT_MOC_LITERAL(20, 255, 10), // "openSerial"
QT_MOC_LITERAL(21, 266, 11), // "closeSerial"
QT_MOC_LITERAL(22, 278, 17), // "sendQueuedCommand"
QT_MOC_LITERAL(23, 296, 8), // "setState"
QT_MOC_LITERAL(24, 305, 5), // "State"
QT_MOC_LITERAL(25, 311, 29), // "enableControlsForCurrentState"
QT_MOC_LITERAL(26, 341, 12), // "showAboutBox"
QT_MOC_LITERAL(27, 354, 14), // "aboutBoxClosed"
QT_MOC_LITERAL(28, 369, 13), // "showLogViewer"
QT_MOC_LITERAL(29, 383, 15), // "logViewerClosed"
QT_MOC_LITERAL(30, 399, 10), // "showPrompt"
QT_MOC_LITERAL(31, 410, 4), // "text"
QT_MOC_LITERAL(32, 415, 43), // "QList<QPair<QString,Prompter:..."
QT_MOC_LITERAL(33, 459, 7), // "buttons"
QT_MOC_LITERAL(34, 467, 12), // "showSettings"
QT_MOC_LITERAL(35, 480, 12), // "updateConfig"
QT_MOC_LITERAL(36, 493, 4), // "name"
QT_MOC_LITERAL(37, 498, 18), // "truncateConsoleLog"
QT_MOC_LITERAL(38, 517, 16), // "downloadProgress"
QT_MOC_LITERAL(39, 534, 4), // "recd"
QT_MOC_LITERAL(40, 539, 5), // "total"
QT_MOC_LITERAL(41, 545, 16) // "downloadFinished"

    },
    "MainDialog\0gotPrompt\0\0showPromptResult\0"
    "clicked_button\0flashClicked\0"
    "connectDisconnectTerminal\0updatePortList\0"
    "selectFirmwareFile\0flashingDone\0msg\0"
    "success\0disconnectTerminal\0util::Status\0"
    "readSerial\0writeSerial\0reboot\0"
    "configureWiFi\0uploadFile\0platformChanged\0"
    "openSerial\0closeSerial\0sendQueuedCommand\0"
    "setState\0State\0enableControlsForCurrentState\0"
    "showAboutBox\0aboutBoxClosed\0showLogViewer\0"
    "logViewerClosed\0showPrompt\0text\0"
    "QList<QPair<QString,Prompter::ButtonRole> >\0"
    "buttons\0showSettings\0updateConfig\0"
    "name\0truncateConsoleLog\0downloadProgress\0"
    "recd\0total\0downloadFinished"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  159,    2, 0x06 /* Public */,
       3,    1,  160,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,  163,    2, 0x0a /* Public */,
       6,    0,  164,    2, 0x0a /* Public */,
       7,    0,  165,    2, 0x08 /* Private */,
       8,    0,  166,    2, 0x08 /* Private */,
       9,    2,  167,    2, 0x08 /* Private */,
      12,    0,  172,    2, 0x08 /* Private */,
      14,    0,  173,    2, 0x08 /* Private */,
      15,    0,  174,    2, 0x08 /* Private */,
      16,    0,  175,    2, 0x08 /* Private */,
      17,    0,  176,    2, 0x08 /* Private */,
      18,    0,  177,    2, 0x08 /* Private */,
      19,    0,  178,    2, 0x08 /* Private */,
      20,    0,  179,    2, 0x08 /* Private */,
      21,    0,  180,    2, 0x08 /* Private */,
      22,    0,  181,    2, 0x08 /* Private */,
      23,    1,  182,    2, 0x08 /* Private */,
      25,    0,  185,    2, 0x08 /* Private */,
      26,    0,  186,    2, 0x08 /* Private */,
      27,    0,  187,    2, 0x08 /* Private */,
      28,    0,  188,    2, 0x08 /* Private */,
      29,    0,  189,    2, 0x08 /* Private */,
      30,    2,  190,    2, 0x08 /* Private */,
      34,    0,  195,    2, 0x08 /* Private */,
      35,    1,  196,    2, 0x08 /* Private */,
      37,    0,  199,    2, 0x08 /* Private */,
      38,    2,  200,    2, 0x08 /* Private */,
      41,    0,  205,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   10,   11,
    0x80000000 | 13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 13,
    0x80000000 | 13,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 24,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 32,   31,   33,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   36,
    QMetaType::Void,
    QMetaType::Void, QMetaType::LongLong, QMetaType::LongLong,   39,   40,
    QMetaType::Void,

       0        // eod
};

void MainDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainDialog *_t = static_cast<MainDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->gotPrompt(); break;
        case 1: _t->showPromptResult((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->flashClicked(); break;
        case 3: _t->connectDisconnectTerminal(); break;
        case 4: _t->updatePortList(); break;
        case 5: _t->selectFirmwareFile(); break;
        case 6: _t->flashingDone((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 7: { util::Status _r = _t->disconnectTerminal();
            if (_a[0]) *reinterpret_cast< util::Status*>(_a[0]) = _r; }  break;
        case 8: _t->readSerial(); break;
        case 9: _t->writeSerial(); break;
        case 10: _t->reboot(); break;
        case 11: _t->configureWiFi(); break;
        case 12: _t->uploadFile(); break;
        case 13: _t->platformChanged(); break;
        case 14: { util::Status _r = _t->openSerial();
            if (_a[0]) *reinterpret_cast< util::Status*>(_a[0]) = _r; }  break;
        case 15: { util::Status _r = _t->closeSerial();
            if (_a[0]) *reinterpret_cast< util::Status*>(_a[0]) = _r; }  break;
        case 16: _t->sendQueuedCommand(); break;
        case 17: _t->setState((*reinterpret_cast< State(*)>(_a[1]))); break;
        case 18: _t->enableControlsForCurrentState(); break;
        case 19: _t->showAboutBox(); break;
        case 20: _t->aboutBoxClosed(); break;
        case 21: _t->showLogViewer(); break;
        case 22: _t->logViewerClosed(); break;
        case 23: _t->showPrompt((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QList<QPair<QString,Prompter::ButtonRole> >(*)>(_a[2]))); break;
        case 24: _t->showSettings(); break;
        case 25: _t->updateConfig((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 26: _t->truncateConsoleLog(); break;
        case 27: _t->downloadProgress((*reinterpret_cast< qint64(*)>(_a[1])),(*reinterpret_cast< qint64(*)>(_a[2]))); break;
        case 28: _t->downloadFinished(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MainDialog::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainDialog::gotPrompt)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MainDialog::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainDialog::showPromptResult)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject MainDialog::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainDialog.data,
      qt_meta_data_MainDialog,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainDialog.stringdata0))
        return static_cast<void*>(const_cast< MainDialog*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 29;
    }
    return _id;
}

// SIGNAL 0
void MainDialog::gotPrompt()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void MainDialog::showPromptResult(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
