/********************************************************************************
** Form generated from reading UI file 'about.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUT_H
#define UI_ABOUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_About
{
public:
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *logoLabel;
    QSpacerItem *verticalSpacer_3;
    QLabel *bannerLabel;
    QLabel *versionLabel;
    QLineEdit *buildLabel;
    QSpacerItem *verticalSpacer_4;
    QFrame *frame;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QSpacerItem *verticalSpacer;
    QLabel *label_2;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;

    void setupUi(QWidget *About)
    {
        if (About->objectName().isEmpty())
            About->setObjectName(QStringLiteral("About"));
        About->resize(594, 413);
        horizontalLayout = new QHBoxLayout(About);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        logoLabel = new QLabel(About);
        logoLabel->setObjectName(QStringLiteral("logoLabel"));
        logoLabel->setMinimumSize(QSize(256, 256));
        logoLabel->setPixmap(QPixmap(QString::fromUtf8(":/images/mg_iot_256.png")));
        logoLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(logoLabel);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);

        bannerLabel = new QLabel(About);
        bannerLabel->setObjectName(QStringLiteral("bannerLabel"));
        QFont font;
        font.setPointSize(26);
        bannerLabel->setFont(font);
        bannerLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(bannerLabel);

        versionLabel = new QLabel(About);
        versionLabel->setObjectName(QStringLiteral("versionLabel"));
        versionLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(versionLabel);

        buildLabel = new QLineEdit(About);
        buildLabel->setObjectName(QStringLiteral("buildLabel"));

        verticalLayout->addWidget(buildLabel);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_4);


        horizontalLayout->addLayout(verticalLayout);

        frame = new QFrame(About);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Sunken);
        verticalLayout_2 = new QVBoxLayout(frame);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label = new QLabel(frame);
        label->setObjectName(QStringLiteral("label"));
        QFont font1;
        font1.setPointSize(19);
        label->setFont(font1);

        verticalLayout_2->addWidget(label);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        label_2 = new QLabel(frame);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setOpenExternalLinks(true);

        verticalLayout_2->addWidget(label_2);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);

        label_3 = new QLabel(frame);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setOpenExternalLinks(true);

        verticalLayout_2->addWidget(label_3);

        label_4 = new QLabel(frame);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout_2->addWidget(label_4);

        label_5 = new QLabel(frame);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout_2->addWidget(label_5);


        horizontalLayout->addWidget(frame);

        horizontalLayout->setStretch(0, 1);

        retranslateUi(About);

        QMetaObject::connectSlotsByName(About);
    } // setupUi

    void retranslateUi(QWidget *About)
    {
        About->setWindowTitle(QApplication::translate("About", "About", 0));
        logoLabel->setText(QString());
        bannerLabel->setText(QApplication::translate("About", "Mongoose Flashing Tool", 0));
        versionLabel->setText(QString());
        label->setText(QApplication::translate("About", "CESANTA", 0));
        label_2->setText(QApplication::translate("About", "Support and sales: <br/><a href=\"mailto:support@cesanta.com\">support@cesanta.com</a>", 0));
        label_3->setText(QApplication::translate("About", "<a href=\"https://www.cesanta.com/\">www.cesanta.com</a>", 0));
        label_4->setText(QApplication::translate("About", "Phone: +353 1 482 4452", 0));
        label_5->setText(QApplication::translate("About", "Twitter: <a href=\"https://twitter.com/CesantaHQ\">@CesantaHQ</a>", 0));
    } // retranslateUi

};

namespace Ui {
    class About: public Ui_About {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUT_H
