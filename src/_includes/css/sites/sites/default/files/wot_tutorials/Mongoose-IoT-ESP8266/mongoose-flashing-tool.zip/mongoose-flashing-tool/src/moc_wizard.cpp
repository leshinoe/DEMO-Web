/****************************************************************************
** Meta object code from reading C++ file 'wizard.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "wizard/wizard.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'wizard.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_WizardDialog_t {
    QByteArrayData data[53];
    char stringdata0[714];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_WizardDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_WizardDialog_t qt_meta_stringdata_WizardDialog = {
    {
QT_MOC_LITERAL(0, 0, 12), // "WizardDialog"
QT_MOC_LITERAL(1, 13, 16), // "showPromptResult"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 14), // "clicked_button"
QT_MOC_LITERAL(4, 46, 8), // "nextStep"
QT_MOC_LITERAL(5, 55, 8), // "prevStep"
QT_MOC_LITERAL(6, 64, 18), // "currentStepChanged"
QT_MOC_LITERAL(7, 83, 14), // "updatePortList"
QT_MOC_LITERAL(8, 98, 17), // "updateReleaseInfo"
QT_MOC_LITERAL(9, 116, 22), // "updateFirmwareSelector"
QT_MOC_LITERAL(10, 139, 21), // "startFirmwareDownload"
QT_MOC_LITERAL(11, 161, 3), // "url"
QT_MOC_LITERAL(12, 165, 16), // "downloadProgress"
QT_MOC_LITERAL(13, 182, 4), // "recd"
QT_MOC_LITERAL(14, 187, 5), // "total"
QT_MOC_LITERAL(15, 193, 16), // "downloadFinished"
QT_MOC_LITERAL(16, 210, 10), // "showPrompt"
QT_MOC_LITERAL(17, 221, 4), // "text"
QT_MOC_LITERAL(18, 226, 43), // "QList<QPair<QString,Prompter:..."
QT_MOC_LITERAL(19, 270, 7), // "buttons"
QT_MOC_LITERAL(20, 278, 13), // "flashFirmware"
QT_MOC_LITERAL(21, 292, 8), // "fileName"
QT_MOC_LITERAL(22, 301, 20), // "flasherStatusMessage"
QT_MOC_LITERAL(23, 322, 3), // "msg"
QT_MOC_LITERAL(24, 326, 9), // "important"
QT_MOC_LITERAL(25, 336, 16), // "flashingProgress"
QT_MOC_LITERAL(26, 353, 12), // "bytesWritten"
QT_MOC_LITERAL(27, 366, 12), // "flashingDone"
QT_MOC_LITERAL(28, 379, 7), // "success"
QT_MOC_LITERAL(29, 387, 15), // "fwConnectResult"
QT_MOC_LITERAL(30, 403, 12), // "util::Status"
QT_MOC_LITERAL(31, 416, 2), // "st"
QT_MOC_LITERAL(32, 419, 15), // "updateSysConfig"
QT_MOC_LITERAL(33, 435, 6), // "config"
QT_MOC_LITERAL(34, 442, 10), // "doWifiScan"
QT_MOC_LITERAL(35, 453, 18), // "updateWiFiNetworks"
QT_MOC_LITERAL(36, 472, 8), // "networks"
QT_MOC_LITERAL(37, 481, 15), // "wifiNameChanged"
QT_MOC_LITERAL(38, 497, 16), // "updateWiFiStatus"
QT_MOC_LITERAL(39, 514, 20), // "FWClient::WifiStatus"
QT_MOC_LITERAL(40, 535, 2), // "ws"
QT_MOC_LITERAL(41, 538, 14), // "registerDevice"
QT_MOC_LITERAL(42, 553, 29), // "registerDeviceRequestFinished"
QT_MOC_LITERAL(43, 583, 19), // "testCloudConnection"
QT_MOC_LITERAL(44, 603, 7), // "cloudId"
QT_MOC_LITERAL(45, 611, 8), // "cloudKey"
QT_MOC_LITERAL(46, 620, 12), // "clubbyStatus"
QT_MOC_LITERAL(47, 633, 6), // "status"
QT_MOC_LITERAL(48, 640, 15), // "claimBtnClicked"
QT_MOC_LITERAL(49, 656, 12), // "showAboutBox"
QT_MOC_LITERAL(50, 669, 14), // "aboutBoxClosed"
QT_MOC_LITERAL(51, 684, 13), // "showLogViewer"
QT_MOC_LITERAL(52, 698, 15) // "logViewerClosed"

    },
    "WizardDialog\0showPromptResult\0\0"
    "clicked_button\0nextStep\0prevStep\0"
    "currentStepChanged\0updatePortList\0"
    "updateReleaseInfo\0updateFirmwareSelector\0"
    "startFirmwareDownload\0url\0downloadProgress\0"
    "recd\0total\0downloadFinished\0showPrompt\0"
    "text\0QList<QPair<QString,Prompter::ButtonRole> >\0"
    "buttons\0flashFirmware\0fileName\0"
    "flasherStatusMessage\0msg\0important\0"
    "flashingProgress\0bytesWritten\0"
    "flashingDone\0success\0fwConnectResult\0"
    "util::Status\0st\0updateSysConfig\0config\0"
    "doWifiScan\0updateWiFiNetworks\0networks\0"
    "wifiNameChanged\0updateWiFiStatus\0"
    "FWClient::WifiStatus\0ws\0registerDevice\0"
    "registerDeviceRequestFinished\0"
    "testCloudConnection\0cloudId\0cloudKey\0"
    "clubbyStatus\0status\0claimBtnClicked\0"
    "showAboutBox\0aboutBoxClosed\0showLogViewer\0"
    "logViewerClosed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_WizardDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      30,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  164,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  167,    2, 0x08 /* Private */,
       5,    0,  168,    2, 0x08 /* Private */,
       6,    0,  169,    2, 0x08 /* Private */,
       7,    0,  170,    2, 0x08 /* Private */,
       8,    0,  171,    2, 0x08 /* Private */,
       9,    0,  172,    2, 0x08 /* Private */,
      10,    1,  173,    2, 0x08 /* Private */,
      12,    2,  176,    2, 0x08 /* Private */,
      15,    0,  181,    2, 0x08 /* Private */,
      16,    2,  182,    2, 0x08 /* Private */,
      20,    1,  187,    2, 0x08 /* Private */,
      22,    2,  190,    2, 0x08 /* Private */,
      25,    1,  195,    2, 0x08 /* Private */,
      27,    2,  198,    2, 0x08 /* Private */,
      29,    1,  203,    2, 0x08 /* Private */,
      32,    1,  206,    2, 0x08 /* Private */,
      34,    0,  209,    2, 0x08 /* Private */,
      35,    1,  210,    2, 0x08 /* Private */,
      37,    0,  213,    2, 0x08 /* Private */,
      38,    1,  214,    2, 0x08 /* Private */,
      41,    0,  217,    2, 0x08 /* Private */,
      42,    0,  218,    2, 0x08 /* Private */,
      43,    2,  219,    2, 0x08 /* Private */,
      46,    1,  224,    2, 0x08 /* Private */,
      48,    0,  227,    2, 0x08 /* Private */,
      49,    0,  228,    2, 0x08 /* Private */,
      50,    0,  229,    2, 0x08 /* Private */,
      51,    0,  230,    2, 0x08 /* Private */,
      52,    0,  231,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QUrl,   11,
    QMetaType::Void, QMetaType::LongLong, QMetaType::LongLong,   13,   14,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 18,   17,   19,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   23,   24,
    QMetaType::Void, QMetaType::Int,   26,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   23,   28,
    QMetaType::Void, 0x80000000 | 30,   31,
    QMetaType::Void, QMetaType::QJsonObject,   33,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QStringList,   36,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 39,   40,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   44,   45,
    QMetaType::Void, QMetaType::Int,   47,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void WizardDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        WizardDialog *_t = static_cast<WizardDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->showPromptResult((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->nextStep(); break;
        case 2: _t->prevStep(); break;
        case 3: _t->currentStepChanged(); break;
        case 4: _t->updatePortList(); break;
        case 5: _t->updateReleaseInfo(); break;
        case 6: _t->updateFirmwareSelector(); break;
        case 7: _t->startFirmwareDownload((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 8: _t->downloadProgress((*reinterpret_cast< qint64(*)>(_a[1])),(*reinterpret_cast< qint64(*)>(_a[2]))); break;
        case 9: _t->downloadFinished(); break;
        case 10: _t->showPrompt((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QList<QPair<QString,Prompter::ButtonRole> >(*)>(_a[2]))); break;
        case 11: _t->flashFirmware((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: _t->flasherStatusMessage((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 13: _t->flashingProgress((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->flashingDone((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 15: _t->fwConnectResult((*reinterpret_cast< util::Status(*)>(_a[1]))); break;
        case 16: _t->updateSysConfig((*reinterpret_cast< QJsonObject(*)>(_a[1]))); break;
        case 17: _t->doWifiScan(); break;
        case 18: _t->updateWiFiNetworks((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 19: _t->wifiNameChanged(); break;
        case 20: _t->updateWiFiStatus((*reinterpret_cast< FWClient::WifiStatus(*)>(_a[1]))); break;
        case 21: _t->registerDevice(); break;
        case 22: _t->registerDeviceRequestFinished(); break;
        case 23: _t->testCloudConnection((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 24: _t->clubbyStatus((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 25: _t->claimBtnClicked(); break;
        case 26: _t->showAboutBox(); break;
        case 27: _t->aboutBoxClosed(); break;
        case 28: _t->showLogViewer(); break;
        case 29: _t->logViewerClosed(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (WizardDialog::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&WizardDialog::showPromptResult)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject WizardDialog::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_WizardDialog.data,
      qt_meta_data_WizardDialog,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *WizardDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *WizardDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_WizardDialog.stringdata0))
        return static_cast<void*>(const_cast< WizardDialog*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int WizardDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 30)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 30;
    }
    return _id;
}

// SIGNAL 0
void WizardDialog::showPromptResult(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
