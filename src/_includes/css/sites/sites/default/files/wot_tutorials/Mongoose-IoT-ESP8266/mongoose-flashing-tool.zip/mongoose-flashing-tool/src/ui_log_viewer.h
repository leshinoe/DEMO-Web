/********************************************************************************
** Form generated from reading UI file 'log_viewer.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOG_VIEWER_H
#define UI_LOG_VIEWER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LogViewer
{
public:
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *logView;
    QPushButton *clearButton;

    void setupUi(QWidget *About)
    {
        if (About->objectName().isEmpty())
            About->setObjectName(QStringLiteral("About"));
        About->resize(800, 400);
        verticalLayout = new QVBoxLayout(About);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        logView = new QPlainTextEdit(About);
        logView->setObjectName(QStringLiteral("logView"));
        logView->setReadOnly(true);
        logView->setTextInteractionFlags(Qt::TextSelectableByKeyboard|Qt::TextSelectableByMouse);

        verticalLayout->addWidget(logView);

        clearButton = new QPushButton(About);
        clearButton->setObjectName(QStringLiteral("clearButton"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(clearButton->sizePolicy().hasHeightForWidth());
        clearButton->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(clearButton);


        retranslateUi(About);

        QMetaObject::connectSlotsByName(About);
    } // setupUi

    void retranslateUi(QWidget *About)
    {
        About->setWindowTitle(QApplication::translate("LogViewer", "Log", 0));
        clearButton->setText(QApplication::translate("LogViewer", "Clear", 0));
    } // retranslateUi

};

namespace Ui {
    class LogViewer: public Ui_LogViewer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOG_VIEWER_H
