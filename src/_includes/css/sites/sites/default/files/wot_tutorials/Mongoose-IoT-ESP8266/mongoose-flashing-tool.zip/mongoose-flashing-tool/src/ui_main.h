/********************************************************************************
** Form generated from reading UI file 'main.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAIN_H
#define UI_MAIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionConfigure_Wi_Fi;
    QAction *actionLog;
    QAction *actionAbout;
    QAction *actionAbout_Qt;
    QAction *actionOpenWebsite;
    QAction *actionHelp;
    QAction *actionUpload_a_file;
    QAction *actionOpenDashboard;
    QAction *actionSend_feedback;
    QAction *actionSettings;
    QAction *actionTruncate_log_file;
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout;
    QLabel *firmwareLabel;
    QLineEdit *firmwareFileName;
    QPushButton *browseBtn;
    QHBoxLayout *horizontalLayout_2;
    QLabel *platformLabel_2;
    QComboBox *portSelector;
    QLabel *platformLabel;
    QComboBox *platformSelector;
    QPushButton *flashBtn;
    QProgressBar *progressBar;
    QLabel *statusMessage;
    QHBoxLayout *terminalControlsLayout;
    QLabel *talkDeviceConsoleLabel;
    QSpacerItem *horizontalSpacer;
    QPushButton *connectBtn;
    QPushButton *rebootBtn;
    QPushButton *clearBtn;
    QPushButton *uploadBtn;
    QPlainTextEdit *terminal;
    QLineEdit *terminalInput;
    QHBoxLayout *horizontalLayout;
    QLabel *logo;
    QLabel *versionLabel;
    QLabel *label;
    QLabel *label_2;
    QMenuBar *menubar;
    QMenu *menuConfigure;
    QMenu *menuHelp;
    QMenu *menuFile;
    QMenu *menuSettings;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(713, 528);
        actionConfigure_Wi_Fi = new QAction(MainWindow);
        actionConfigure_Wi_Fi->setObjectName(QStringLiteral("actionConfigure_Wi_Fi"));
        actionConfigure_Wi_Fi->setMenuRole(QAction::NoRole);
        actionLog = new QAction(MainWindow);
        actionLog->setObjectName(QStringLiteral("actionLog"));
        actionLog->setMenuRole(QAction::NoRole);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        actionAbout->setMenuRole(QAction::AboutRole);
        actionAbout_Qt = new QAction(MainWindow);
        actionAbout_Qt->setObjectName(QStringLiteral("actionAbout_Qt"));
        actionAbout_Qt->setMenuRole(QAction::AboutQtRole);
        actionOpenWebsite = new QAction(MainWindow);
        actionOpenWebsite->setObjectName(QStringLiteral("actionOpenWebsite"));
        actionHelp = new QAction(MainWindow);
        actionHelp->setObjectName(QStringLiteral("actionHelp"));
        actionUpload_a_file = new QAction(MainWindow);
        actionUpload_a_file->setObjectName(QStringLiteral("actionUpload_a_file"));
        actionOpenDashboard = new QAction(MainWindow);
        actionOpenDashboard->setObjectName(QStringLiteral("actionOpenDashboard"));
        actionSend_feedback = new QAction(MainWindow);
        actionSend_feedback->setObjectName(QStringLiteral("actionSend_feedback"));
        actionSend_feedback->setMenuRole(QAction::ApplicationSpecificRole);
        actionSettings = new QAction(MainWindow);
        actionSettings->setObjectName(QStringLiteral("actionSettings"));
        actionTruncate_log_file = new QAction(MainWindow);
        actionTruncate_log_file->setObjectName(QStringLiteral("actionTruncate_log_file"));
        actionTruncate_log_file->setEnabled(false);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        firmwareLabel = new QLabel(centralwidget);
        firmwareLabel->setObjectName(QStringLiteral("firmwareLabel"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(firmwareLabel->sizePolicy().hasHeightForWidth());
        firmwareLabel->setSizePolicy(sizePolicy);

        gridLayout->addWidget(firmwareLabel, 4, 0, 1, 1);

        firmwareFileName = new QLineEdit(centralwidget);
        firmwareFileName->setObjectName(QStringLiteral("firmwareFileName"));
        firmwareFileName->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(firmwareFileName->sizePolicy().hasHeightForWidth());
        firmwareFileName->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(firmwareFileName, 4, 1, 1, 1);

        browseBtn = new QPushButton(centralwidget);
        browseBtn->setObjectName(QStringLiteral("browseBtn"));

        gridLayout->addWidget(browseBtn, 4, 2, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        platformLabel_2 = new QLabel(centralwidget);
        platformLabel_2->setObjectName(QStringLiteral("platformLabel_2"));
        sizePolicy.setHeightForWidth(platformLabel_2->sizePolicy().hasHeightForWidth());
        platformLabel_2->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(platformLabel_2);

        portSelector = new QComboBox(centralwidget);
        portSelector->setObjectName(QStringLiteral("portSelector"));
        sizePolicy1.setHeightForWidth(portSelector->sizePolicy().hasHeightForWidth());
        portSelector->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(portSelector);

        platformLabel = new QLabel(centralwidget);
        platformLabel->setObjectName(QStringLiteral("platformLabel"));
        sizePolicy.setHeightForWidth(platformLabel->sizePolicy().hasHeightForWidth());
        platformLabel->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(platformLabel);

        platformSelector = new QComboBox(centralwidget);
        platformSelector->insertItems(0, QStringList()
         << QStringLiteral("ESP8266")
         << QStringLiteral("CC3200")
        );
        platformSelector->setObjectName(QStringLiteral("platformSelector"));
        sizePolicy1.setHeightForWidth(platformSelector->sizePolicy().hasHeightForWidth());
        platformSelector->setSizePolicy(sizePolicy1);
        platformSelector->setCurrentText(QStringLiteral("ESP8266"));

        horizontalLayout_2->addWidget(platformSelector);


        gridLayout->addLayout(horizontalLayout_2, 0, 0, 1, 6);

        flashBtn = new QPushButton(centralwidget);
        flashBtn->setObjectName(QStringLiteral("flashBtn"));
        flashBtn->setMinimumSize(QSize(150, 0));

        gridLayout->addWidget(flashBtn, 4, 3, 1, 3);


        verticalLayout->addLayout(gridLayout);

        progressBar = new QProgressBar(centralwidget);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setValue(0);

        verticalLayout->addWidget(progressBar);

        statusMessage = new QLabel(centralwidget);
        statusMessage->setObjectName(QStringLiteral("statusMessage"));
        statusMessage->setTextFormat(Qt::RichText);
        statusMessage->setOpenExternalLinks(true);

        verticalLayout->addWidget(statusMessage);

        terminalControlsLayout = new QHBoxLayout();
        terminalControlsLayout->setObjectName(QStringLiteral("terminalControlsLayout"));
        terminalControlsLayout->setContentsMargins(-1, 0, -1, -1);
        talkDeviceConsoleLabel = new QLabel(centralwidget);
        talkDeviceConsoleLabel->setObjectName(QStringLiteral("talkDeviceConsoleLabel"));

        terminalControlsLayout->addWidget(talkDeviceConsoleLabel);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        terminalControlsLayout->addItem(horizontalSpacer);

        connectBtn = new QPushButton(centralwidget);
        connectBtn->setObjectName(QStringLiteral("connectBtn"));

        terminalControlsLayout->addWidget(connectBtn);

        rebootBtn = new QPushButton(centralwidget);
        rebootBtn->setObjectName(QStringLiteral("rebootBtn"));

        terminalControlsLayout->addWidget(rebootBtn);

        clearBtn = new QPushButton(centralwidget);
        clearBtn->setObjectName(QStringLiteral("clearBtn"));

        terminalControlsLayout->addWidget(clearBtn);

        uploadBtn = new QPushButton(centralwidget);
        uploadBtn->setObjectName(QStringLiteral("uploadBtn"));

        terminalControlsLayout->addWidget(uploadBtn);


        verticalLayout->addLayout(terminalControlsLayout);

        terminal = new QPlainTextEdit(centralwidget);
        terminal->setObjectName(QStringLiteral("terminal"));
        terminal->setReadOnly(true);
        terminal->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        terminal->setMaximumBlockCount(4096);

        verticalLayout->addWidget(terminal);

        terminalInput = new QLineEdit(centralwidget);
        terminalInput->setObjectName(QStringLiteral("terminalInput"));

        verticalLayout->addWidget(terminalInput);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(-1, 10, -1, -1);
        logo = new QLabel(centralwidget);
        logo->setObjectName(QStringLiteral("logo"));
        logo->setOpenExternalLinks(true);

        horizontalLayout->addWidget(logo);

        versionLabel = new QLabel(centralwidget);
        versionLabel->setObjectName(QStringLiteral("versionLabel"));

        horizontalLayout->addWidget(versionLabel);

        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label, 0, Qt::AlignRight);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_2->setOpenExternalLinks(true);

        horizontalLayout->addWidget(label_2);


        verticalLayout->addLayout(horizontalLayout);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 713, 25));
        menuConfigure = new QMenu(menubar);
        menuConfigure->setObjectName(QStringLiteral("menuConfigure"));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        menuSettings = new QMenu(menubar);
        menuSettings->setObjectName(QStringLiteral("menuSettings"));
        MainWindow->setMenuBar(menubar);
        QWidget::setTabOrder(portSelector, platformSelector);
        QWidget::setTabOrder(platformSelector, firmwareFileName);
        QWidget::setTabOrder(firmwareFileName, browseBtn);
        QWidget::setTabOrder(browseBtn, flashBtn);
        QWidget::setTabOrder(flashBtn, terminal);
        QWidget::setTabOrder(terminal, terminalInput);
        QWidget::setTabOrder(terminalInput, connectBtn);
        QWidget::setTabOrder(connectBtn, rebootBtn);
        QWidget::setTabOrder(rebootBtn, clearBtn);
        QWidget::setTabOrder(clearBtn, uploadBtn);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuConfigure->menuAction());
        menubar->addAction(menuSettings->menuAction());
        menubar->addAction(menuHelp->menuAction());
        menuConfigure->addAction(actionConfigure_Wi_Fi);
        menuConfigure->addAction(actionOpenDashboard);
        menuHelp->addAction(actionHelp);
        menuHelp->addAction(actionOpenWebsite);
        menuHelp->addAction(actionSend_feedback);
        menuHelp->addAction(actionLog);
        menuHelp->addAction(actionAbout);
        menuHelp->addAction(actionAbout_Qt);
        menuFile->addAction(actionUpload_a_file);
        menuFile->addAction(actionTruncate_log_file);
        menuSettings->addAction(actionSettings);

        retranslateUi(MainWindow);
        QObject::connect(clearBtn, SIGNAL(clicked()), terminal, SLOT(clear()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Mongoose Flashing Tool", 0));
        actionConfigure_Wi_Fi->setText(QApplication::translate("MainWindow", "&Connect to Wi-Fi", 0));
        actionLog->setText(QApplication::translate("MainWindow", "&Log", 0));
        actionAbout->setText(QApplication::translate("MainWindow", "&About", 0));
        actionAbout_Qt->setText(QApplication::translate("MainWindow", "About &Qt", 0));
        actionOpenWebsite->setText(QApplication::translate("MainWindow", "&Mongoose IoT website", 0));
        actionHelp->setText(QApplication::translate("MainWindow", "&Help", 0));
        actionUpload_a_file->setText(QApplication::translate("MainWindow", "&Upload", 0));
        actionOpenDashboard->setText(QApplication::translate("MainWindow", "&Open dashboard", 0));
        actionSend_feedback->setText(QApplication::translate("MainWindow", "Send &feedback", 0));
        actionSettings->setText(QApplication::translate("MainWindow", "&Advanced settings", 0));
        actionTruncate_log_file->setText(QApplication::translate("MainWindow", "&Truncate log file", 0));
        firmwareLabel->setText(QApplication::translate("MainWindow", "Firmware:", 0));
        browseBtn->setText(QApplication::translate("MainWindow", "Browse...", 0));
        platformLabel_2->setText(QApplication::translate("MainWindow", "Port:", 0));
        platformLabel->setText(QApplication::translate("MainWindow", "Platform:", 0));
        flashBtn->setText(QApplication::translate("MainWindow", "&Flash", 0));
        statusMessage->setText(QString());
        talkDeviceConsoleLabel->setText(QApplication::translate("MainWindow", "Device console:", 0));
        connectBtn->setText(QApplication::translate("MainWindow", "&Connect", 0));
        rebootBtn->setText(QApplication::translate("MainWindow", "Reboot", 0));
        clearBtn->setText(QApplication::translate("MainWindow", "C&lear", 0));
        uploadBtn->setText(QApplication::translate("MainWindow", "Upload file", 0));
        terminalInput->setText(QString());
        logo->setText(QApplication::translate("MainWindow", "<a href=\"https://www.cesanta.com/products/mongoose-iot\"><img width=32 height=33 src=\":/images/mg_iot_32.png\"></a>", 0));
        versionLabel->setText(QString());
        label->setText(QApplication::translate("MainWindow", "\302\251 2015-2016 Cesanta", 0));
        label_2->setText(QApplication::translate("MainWindow", "<a href=\"https://github.com/cesanta/mongoose-iot\">Mongoose IoT documentation</a>", 0));
        menuConfigure->setTitle(QApplication::translate("MainWindow", "Co&nnect", 0));
        menuHelp->setTitle(QApplication::translate("MainWindow", "&Help", 0));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", 0));
        menuSettings->setTitle(QApplication::translate("MainWindow", "S&ettings", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAIN_H
